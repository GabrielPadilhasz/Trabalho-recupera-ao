let ano = document.querySelector("#ano");
let valor = document.querySelector("#valor");
let resultado = document.querySelector("#resultado");

function calcularImposto(){

    let anoFabricacao = parseInt(ano.value);
    let valorTabela = parseFloat(valor.value);

    let taxa;

    if (anoFabricacao < 1990) {
        taxa = 0.01;
    } else {
        taxa = 0.015;
    }

    let imposto = valorTabela * taxa;

    // Coloquei toFixed Professor porque estava dando erro com numeros quebrados pra ele mostra ate duas casas decimais
    resultado.textContent = imposto.toFixed(2);


}