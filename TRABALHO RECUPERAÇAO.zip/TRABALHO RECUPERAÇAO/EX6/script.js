let saldoMedioInput = document.getElementById('saldoMedio01');
let resultado = document.querySelector("#resultado");

function calcularCredito(){

    let saldoMedio = parseFloat(saldoMedioInput.value);

    let percentualCredito;

    if (saldoMedio >= 0 && saldoMedio <= 200) {
        percentualCredito = 0;
    } else if (saldoMedio >= 201 && saldoMedio <= 400) {
        percentualCredito = 20;
    } else if (saldoMedio >= 401 && saldoMedio <= 600) {
        percentualCredito = 30;
    } else if (saldoMedio > 600) {
        percentualCredito = 40;
    } else {

    }

    let valorCredito = saldoMedio * (percentualCredito / 100);

    let resultadoHTML = `<h3>Resultado do Cálculo</h3>`;
    resultadoHTML += `<p>Saldo Médio: R$ ${saldoMedio.toFixed(2)}</p>`;
    resultadoHTML += `<p>Valor do Crédito: R$ ${valorCredito.toFixed(2)}</p>`;

    resultado.innerHTML = resultadoHTML;
}
