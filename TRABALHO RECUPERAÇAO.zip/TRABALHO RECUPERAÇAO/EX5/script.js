let codigo = document.querySelector("#codigo");
let salario = document.querySelector("#salario");
let resultado = document.querySelector("#resultado");

function calcularNovoSalario(){

    let codigoCargo = parseInt(codigo.value);
    let salarioAtual = parseFloat(salario.value);

    let novoSalario;

    if (codigoCargo === 101) { 
        novoSalario = salarioAtual * 1.1;
    } else if (codigoCargo === 102) { 
        novoSalario = salarioAtual * 1.2;
    } else if (codigoCargo === 103) { 
        novoSalario = salarioAtual * 1.3;
    } else { 
        novoSalario = salarioAtual * 1.4;
    }
  
    let diferenca = novoSalario - salarioAtual;

    let resultadoTexto = `Resultado do Cálculo`;
    resultadoTexto += `Salário atual: R$ ${salarioAtual.toFixed(2)}`;
    resultadoTexto += `Novo salário: R$ ${novoSalario.toFixed(2)}`;
    resultadoTexto += `Diferença: R$ ${diferenca.toFixed(2)}`;

    resultado.textContent = resultadoTexto;
}
