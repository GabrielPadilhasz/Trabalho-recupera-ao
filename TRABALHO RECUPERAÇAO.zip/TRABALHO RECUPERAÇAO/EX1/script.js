let N1 = document.querySelector("#N1");
let N2 = document.querySelector("#N2");
let N3 = document.querySelector("#N3");
let N4 = document.querySelector("#N4");
let N5 = document.querySelector("#N5");
let Resultado = document.querySelector("#Resultado");


function ORDEM(){

    let num1 = parseInt(N1.value);
    let num2 = parseInt(N2.value);
    let num3 = parseInt(N3.value);
    let num4 = parseInt(N4.value);
    let num5 = parseInt(N5.value);

    let valores = [num1, num2, num3, num4, num5];

    valores.sort(function(a, b) {
        return b - a;
    });

    Resultado.textContent = "Valores Ordenados (decrescente)" + valores;
}
