function calcularValor() {

    let preco = parseFloat(document.getElementById('preco').value);
    let condicao = document.getElementById('condicao').value;

    let valorAPagar;

    if (condicao === 'a') { 
        valorAPagar = preco * 0.9;
    } else if (condicao === 'b') {
        valorAPagar = preco * 0.85;
    } else if (condicao === 'c') { 
        valorAPagar = preco;
    } else if (condicao === 'd') { 
        valorAPagar = preco * 1.1; 
    } else {
    }

  
    let resultadoHTML = `<h3>Valor a Pagar</h3>`;
    resultadoHTML += `<p>Preço do Produto: R$ ${preco.toFixed(2)}</p>`;
    resultadoHTML += `<p>Valor a Pagar: R$ ${valorAPagar.toFixed(2)}</p>`;


    document.getElementById('resultado').innerHTML = resultadoHTML;
}
