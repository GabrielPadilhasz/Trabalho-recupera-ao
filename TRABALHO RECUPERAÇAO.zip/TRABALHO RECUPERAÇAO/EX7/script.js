function calcularValor() {
    let codigo = document.getElementById('codigo').value;
    let quantidade = parseInt(document.getElementById('quantidade').value);

    let preco;

    if (codigo === '100') {
        preco = 11.00;
    } else if (codigo === '101') { 
        preco = 8.50;
    } else if (codigo === '102') {
        preco = 8.00;
    } else if (codigo === '103') {
        preco = 9.00;
    } else if (codigo === '104') {
        preco = 10.00;
    } else if (codigo === '105') {
        preco = 4.50;
    } else {

    }

    let valorTotal = preco * quantidade;

    let resultadoHTML = `Valor a Pagar/`;
    resultadoHTML += `Quantidade ${quantidade}/`;
    resultadoHTML += `Valor Total: R$ ${valorTotal.toFixed(2)}`;

    document.getElementById('resultado').textContent = resultadoHTML;
}
