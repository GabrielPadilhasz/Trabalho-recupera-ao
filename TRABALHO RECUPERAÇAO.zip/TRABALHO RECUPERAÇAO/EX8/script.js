function calcularPesoIdeal() {
    let altura = parseFloat(document.getElementById('altura').value);
    let sexo = document.getElementById('sexo').value;

    let pesoIdeal;

    if (sexo === 'homem') {
        pesoIdeal = (72.7 * altura) - 58;
    } else if (sexo === 'mulher') {
        pesoIdeal = (62.1 * altura) - 44.7;
    } else {
        alert("Selecione um sexo válido.");
        return;
    }

    let resultadoHTML = `<h3>Peso Ideal</h3>`;
    resultadoHTML += `<p>Para ${altura.toFixed(2)}m, o peso ideal e: ${pesoIdeal.toFixed(2)}kg</p>`;

    // nessa aqui usai o innerHTMl invez do textcontent achei melhor pq ela nao le ao pe da letra 
   
    document.getElementById('resultado').innerHTML = resultadoHTML;
}
